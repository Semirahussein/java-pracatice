
//import java.util.Scanner;
import java.util.Arrays;

class Exercise {
    public static void main(String[] args) {
        // Scanner scan = new Scanner(System.in);
        /*
         * int num1 = 12;
         * int num2 = 11;
         * String thestring = String.format("the num 1 is %d", num1);
         * System.out.println(thestring);
         * String name = "none of YoUR BUSINESS";
         * String name2 = "none of your business";
         * System.out.println(name.equalsIgnoreCase(name2));
         * System.out.println(name.toUpperCase());
         * System.out.println(name.replace("none", "it's"));
         * System.out.println(name2.contains("YOUR"));
         * // System.out.println("nu8m 2 is: %d",num2);
         * System.out.println("enter name");
         * String name3 = scan.nextLine();
         * 
         * System.out.println(name3);
         * System.out.println("enter num");
         * int number = scan.nextInt();
         * scan.nextLine();
         * System.out.println("enter name4");
         * 
         * String name4 = scan.nextLine();
         * System.out.printf("hi there, here is %s", name4);
         * 
         * 
         * //creating a simple calculator
         * System.out.println("enter nujm 1:");
         * double num1 = scan.nextDouble();
         * // scan.nextDouble();
         * System.out.println("enter num 2:");
         * double num2 = scan.nextDouble();
         * System.out.println("what operation?");
         * scan.nextLine();
         * String operation = scan.nextLine();
         * 
         * if (operation.equalsIgnoreCase("sum")) {
         * System.out.printf("the sum is: %f", num1 + num2);
         * } else if (operation.equalsIgnoreCase("mult")) {
         * 
         * System.out.printf("the mult is: %f", num1 * num2);
         * } else if (operation.equalsIgnoreCase("div")) {
         * System.out.printf("the divided is: %f", num1 / num2);
         * 
         * } else if (operation.equalsIgnoreCase("sub")) {
         * System.out.printf("the subtracted is: %f", num1 - num2);
         * 
         * } else {
         * System.out.println("operation not recognized");
         * }
         * 
         * scan.close();
         */
        char firstArr[] = { 'a', 'd', 't', 'h', 'j', 'u', 'r', 'l' };
        char copy[] = Arrays.copyOf(firstArr, firstArr.length);

        // Arrays.sort(firstArr, start, end);
        // Arrays.sort(firstArr);
        // char find = 'd';
        // int index = Arrays.binarySearch(firstArr, find);
        Arrays.fill(firstArr, 's');
        System.out.println(Arrays.toString(firstArr));

        System.out.println(Arrays.toString(copy));

    }
}